"""
arc_agi3_bridge.py - Kaggle ARC-AGI-3 adapter for ACCAAgent.

This module keeps the competition notebook thin. It installs no packages and
makes no network calls; the notebook is responsible for installing the official
SDK from Kaggle's offline `arc_agi_3_wheels/` input directory.

Part of ACCA (Active Causal Compression Agent)
ARC Prize 2026 . Paper Track
"""
from __future__ import annotations

import glob
import importlib
import types
import sys
from pathlib import Path
from typing import Any, Mapping

import numpy as np

from src.agent import ACCAAgent, MechanicMemory


def _add_official_agent_paths() -> None:
    """Expose Kaggle's attached ARC-AGI-3-Agents repo to Python imports."""
    patterns = [
        "/kaggle/input/competitions/arc-prize-2026-arc-agi-3/ARC-AGI-3-Agents",
        "/kaggle/input/**/ARC-AGI-3-Agents",
        "/kaggle/input/**/ARC-AGI-3-Agents/*",
        "/kaggle/input/**/ARC-AGI-3-Agents/**/*",
        "/kaggle/input/**/agents",
        "/kaggle/working/**/ARC-AGI-3-Agents",
        "/kaggle/working/**/ARC-AGI-3-Agents/*",
        "/kaggle/working/**/ARC-AGI-3-Agents/**/*",
        "/kaggle/working/**/agents",
    ]
    for pattern in patterns:
        for path in sorted(glob.glob(pattern, recursive=True)):
            root = Path(path)
            if root.name == "agents":
                root = root.parent
            if root.is_dir() and (root / "agents").exists() and str(root) not in sys.path:
                sys.path.insert(0, str(root))
            if root.is_file() and root.name == "__init__.py" and root.parent.name == "agents":
                parent = root.parent.parent
                if str(parent) not in sys.path:
                    sys.path.insert(0, str(parent))


def _official_agents_root() -> Path | None:
    candidates = [
        Path("/kaggle/input/competitions/arc-prize-2026-arc-agi-3/ARC-AGI-3-Agents"),
    ]
    candidates.extend(Path(p) for p in glob.glob("/kaggle/input/**/ARC-AGI-3-Agents", recursive=True))
    candidates.extend(Path(p).parent for p in glob.glob("/kaggle/input/**/agents", recursive=True))
    for root in candidates:
        if (root / "agents" / "swarm.py").exists():
            return root
    return None


def _ensure_lightweight_agents_package(root: Path) -> None:
    """Register `agents` as a package without executing its heavy __init__.py."""
    pkg = sys.modules.get("agents")
    if pkg is None or not hasattr(pkg, "__path__"):
        pkg = types.ModuleType("agents")
        pkg.__path__ = [str(root / "agents")]
        sys.modules["agents"] = pkg
    elif str(root / "agents") not in pkg.__path__:
        pkg.__path__.insert(0, str(root / "agents"))


def _import_official_agent_base():
    root = _official_agents_root()
    if root is not None:
        _ensure_lightweight_agents_package(root)
    return importlib.import_module("agents.agent").Agent


def _import_official_swarm():
    root = _official_agents_root()
    if root is not None:
        _ensure_lightweight_agents_package(root)
    return importlib.import_module("agents.swarm").Swarm


def _import_arcade_api():
    errors: list[str] = []
    for module_name in ("arc_agi_3", "arc_agi", "arc_agi.arcade"):
        try:
            module = importlib.import_module(module_name)
            return module.Arcade, module.OperationMode
        except Exception as exc:  # pragma: no cover - depends on Kaggle SDK.
            errors.append(f"{module_name}: {exc}")
    raise ModuleNotFoundError("Could not import Arcade/OperationMode from ARC SDK: " + "; ".join(errors))


def _import_game_action_api():
    module = importlib.import_module("arcengine")
    return module.GameAction, module.GameState


def _competition_mode_available() -> bool:
    import os

    return bool(os.environ.get("ARC_API_KEY") or os.environ.get("ARC_AGI_API_KEY"))


def _public_environment_dir() -> str | None:
    for path in glob.glob("/kaggle/input/**/environment_files", recursive=True):
        if Path(path).is_dir():
            return path
    return None


def _game_id_of(game: Any) -> str:
    value = _get_value(game, ("game_id", "id", "name"))
    if value is not None:
        return str(value)
    return str(game)


def _agent_path_diagnostics() -> str:
    candidates: list[str] = []
    for pattern in (
        "/kaggle/input/**/agents",
        "/kaggle/input/**/agents/__init__.py",
        "/kaggle/input/**/ARC-AGI-3-Agents",
        "/kaggle/input/**/Swarm.py",
        "/kaggle/input/**/swarm.py",
    ):
        candidates.extend(glob.glob(pattern, recursive=True))
    visible = [p for p in sys.path if "agent" in p.lower() or "arc-agi" in p.lower()]
    return f"agent candidates={candidates[:30]} sys.path={visible[:30]}"


try:  # Local development does not have the Kaggle SDK installed.
    _add_official_agent_paths()
    _OfficialAgent = _import_official_agent_base()
except Exception:  # pragma: no cover - exercised only when SDK is absent.
    _OfficialAgent = object


def _get_value(obj: Any, names: tuple[str, ...]) -> Any:
    for name in names:
        if isinstance(obj, Mapping) and name in obj:
            return obj[name]
        if hasattr(obj, name):
            return getattr(obj, name)
    return None


def _extract_grid(frame: Any) -> np.ndarray:
    grid = _get_value(frame, ("grid", "frame", "observation", "board"))
    if grid is None:
        data = _get_value(frame, ("data", "payload"))
        if data is not None:
            grid = _get_value(data, ("grid", "frame", "observation", "board"))
    if grid is None:
        state = _get_value(frame, ("state",))
        if isinstance(state, (list, tuple, np.ndarray)):
            grid = state
    if grid is None:
        raise ValueError("could not extract grid from ARC-AGI-3 frame")
    arr = np.asarray(grid, dtype=np.uint8)
    if arr.size == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    if arr.ndim == 3 and arr.shape[0] == 1:
        arr = arr[0]
    if arr.ndim == 3 and arr.shape[-1] in (3, 4):
        arr = arr[..., 0]
    if arr.ndim == 3 and arr.shape[0] <= 64 and arr.shape[1] > 1 and arr.shape[2] > 1:
        arr = np.maximum.reduce(arr, axis=0)
    if arr.ndim != 2:
        raise ValueError(f"ARC-AGI-3 grid must be 2D, got shape {arr.shape}")
    return arr


def _extract_action_space(frame: Any) -> list[str]:
    action_space = _get_value(frame, ("action_space", "available_actions", "actions"))
    if action_space is None:
        data = _get_value(frame, ("data", "payload", "game"))
        if data is not None:
            action_space = _get_value(data, ("action_space", "available_actions", "actions"))
    if action_space is None:
        return [
            "RESET",
            "ACTION1",
            "ACTION2",
            "ACTION3",
            "ACTION4",
            "ACTION5",
            "ACTION6",
            "ACTION7",
        ]
    return [_normalize_action_name(action) for action in action_space]


def _normalize_action_name(action: Any) -> str:
    if hasattr(action, "name"):
        name = str(action.name)
        if name.startswith("ACTION") or name == "RESET":
            return name
    text = str(action).split()[0]
    if "." in text:
        text = text.rsplit(".", 1)[-1]
    if text.startswith("ACTION") or text == "RESET":
        return text
    if text.isdigit():
        number = int(text)
        if 1 <= number <= 7:
            return f"ACTION{number}"
        if number == 0:
            return "RESET"
    value = getattr(action, "value", None)
    if value is not None and value is not action:
        return _normalize_action_name(value)
    return text


def _extract_game_id(frame: Any) -> str:
    value = _get_value(frame, ("game_id", "game", "environment_id", "env_id", "id"))
    if value is None:
        data = _get_value(frame, ("data", "payload"))
        if data is not None:
            value = _get_value(data, ("game_id", "game", "environment_id", "env_id", "id"))
    return "kaggle" if value is None else str(value)


def _extract_status(frame: Any) -> str:
    value = _get_value(frame, ("state", "status", "game_state"))
    if value is None:
        return ""
    if hasattr(value, "name"):
        return str(value.name)
    return str(value)


def _to_game_action(action: str):
    try:
        GameAction, _ = _import_game_action_api()
    except Exception:  # Local tests run without arcengine.
        return action
    parts = action.split()
    base = parts[0]
    game_action = getattr(GameAction, base)
    if game_action.is_complex():
        x = int(parts[2]) if len(parts) >= 3 else 0
        y = int(parts[1]) if len(parts) >= 2 else 0
        game_action.set_data({"x": x, "y": y})
        game_action.reasoning = {
            "desired_action": base,
            "my_reason": "ACCA selected coordinate action",
        }
    elif game_action.is_simple():
        game_action.reasoning = f"ACCA selected {base}"
    return game_action


def _frame_signature(grid: np.ndarray) -> tuple:
    """Compact descriptor for detecting level transitions: (shape, color-palette,
    non-bg cell count). Cheap to compute; coarse enough to ignore single-cell
    edits but catch new-level layouts."""
    colors = tuple(sorted(int(c) for c in np.unique(grid)))
    return (tuple(grid.shape), colors, int(np.count_nonzero(grid)))


def _is_level_transition(prev_sig: tuple, curr_sig: tuple) -> bool:
    """A grid shape change or a color-palette change is always a transition.
    A >=70% jump in non-bg cell count is treated as one too (typical mid-level
    actions move 1-2 cells, not 70% of them)."""
    if prev_sig[0] != curr_sig[0]:
        return True
    if set(prev_sig[1]) != set(curr_sig[1]):
        return True
    prev_n, curr_n = prev_sig[2], curr_sig[2]
    denom = max(prev_n, curr_n)
    if denom > 0 and abs(prev_n - curr_n) / denom >= 0.7:
        return True
    return False


class KaggleACCAAgent(_OfficialAgent):
    """Official-API wrapper around the SDK-independent ACCAAgent."""

    # Raised from 80 (May 2026 scorecard analysis showed L1 burn at 60-80 actions
    # without progress on every click game). The SDK enforces its own per-level
    # cap of ~2x baseline; this just stops us from also leaving budget on the table.
    MAX_ACTIONS = 300

    def __init__(self, *args: Any, memory: MechanicMemory | None = None, **kwargs: Any):
        if _OfficialAgent is not object:
            super().__init__(*args, **kwargs)
        else:
            for name, value in kwargs.items():
                setattr(self, name, value)
            self.frames = []
            self.action_counter = 0
        self.memory = memory or MechanicMemory()
        self.agent: ACCAAgent | None = None
        self.game_id: str | None = None
        self.last_action: str | None = None
        self.probe_step = 0
        self.click_targets: list[tuple[int, int]] = []
        self._prev_signature: tuple | None = None
        self._consecutive_game_overs = 0

    def main(self) -> None:
        """Run one ARC-AGI-3 environment without depending on official Swarm.

        Emits a one-line timing log every 10 actions so you can confirm where
        time goes (choose_action vs env.step). Toggle off with ACCA_QUIET=1.
        """
        if not hasattr(self, "arc_env") or self.arc_env is None:
            raise RuntimeError("KaggleACCAAgent requires an arc_env before main().")

        import os
        import time

        quiet = os.environ.get("ACCA_QUIET") == "1"
        log_every = 10

        latest_frame = self._latest_frame_from_env()
        if not getattr(self, "frames", None):
            self.frames = [latest_frame]

        self.action_counter = int(getattr(self, "action_counter", 0))
        game_t0 = time.perf_counter()
        cum_choose = 0.0
        cum_step = 0.0
        while not self.is_done(self.frames, latest_frame) and self.action_counter < self.MAX_ACTIONS:
            t0 = time.perf_counter()
            action = self.choose_action(self.frames, latest_frame)
            t1 = time.perf_counter()
            frame = self._take_arc_action(action)
            t2 = time.perf_counter()
            cum_choose += t1 - t0
            cum_step += t2 - t1

            if frame is not None:
                latest_frame = frame
                if hasattr(self, "append_frame"):
                    self.append_frame(frame)
                else:
                    self.frames.append(frame)
            self.action_counter += 1

            if not quiet and self.action_counter % log_every == 0:
                status = _extract_status(latest_frame).upper() or "?"
                print(
                    f"[{self.game_id}] #{self.action_counter:4d}  "
                    f"avg_choose={1000 * cum_choose / self.action_counter:6.1f}ms  "
                    f"avg_step={1000 * cum_step / self.action_counter:6.1f}ms  "
                    f"last_act={getattr(action, 'name', str(action))[:16]}  "
                    f"status={status}",
                    flush=True,
                )

            status = _extract_status(latest_frame).upper()
            if status == "GAME_OVER":
                self._consecutive_game_overs += 1
                if self._consecutive_game_overs >= 3:
                    break
            else:
                self._consecutive_game_overs = 0

        if not quiet:
            wall = time.perf_counter() - game_t0
            print(
                f"[{self.game_id}] DONE in {wall:.1f}s ({self.action_counter} actions, "
                f"choose={1000 * cum_choose:.0f}ms total, step={1000 * cum_step:.0f}ms total)",
                flush=True,
            )
            # End-of-game diagnostic: action breakdown + learned-transition counts.
            # This is the key signal we're missing — at end-of-game we should see
            # what the agent was actually doing.
            inner = getattr(self, "agent", None)
            if inner is not None:
                from collections import Counter
                breakdown = Counter()
                for a in getattr(inner, "level_actions", []):
                    base = a.split()[0]
                    breakdown[base] += 1
                top = ", ".join(f"{a}={n}" for a, n in breakdown.most_common(8))
                ntrans = sum(len(v) for v in getattr(inner, "_novel_transitions", {}).values())
                nstates = len(getattr(inner, "_novel_transitions", {}))
                print(
                    f"[{self.game_id}] action breakdown: {top}",
                    flush=True,
                )
                print(
                    f"[{self.game_id}] learned transitions: {ntrans} novel actions across {nstates} states",
                    flush=True,
                )
                stats = getattr(inner, "stats", None)
                if stats is not None:
                    action_calls = getattr(stats, "action_calls", {})
                    action_changes = getattr(stats, "action_changes", {})
                    action_novel = getattr(stats, "action_novel", {})
                    parts = []
                    for action_name, calls in sorted(
                        action_calls.items(),
                        key=lambda item: (-item[1], item[0]),
                    )[:8]:
                        changes = action_changes.get(action_name, 0)
                        novels = action_novel.get(action_name, 0)
                        parts.append(f"{action_name}:{changes}/{novels}/{calls}")
                    if parts:
                        print(
                            f"[{self.game_id}] effectiveness changed/novel/calls: "
                            + ", ".join(parts),
                            flush=True,
                        )
                    cell_calls = getattr(stats, "cell_calls", {})
                    if cell_calls:
                        unique_cells = len(cell_calls)
                        total_clicks = sum(cell_calls.values())
                        changed_cells = len(getattr(stats, "cell_changes", {}))
                        novel_cells = len(getattr(stats, "cell_novel", {}))
                        print(
                            f"[{self.game_id}] click cells unique={unique_cells} "
                            f"changed={changed_cells} novel={novel_cells} total={total_clicks}",
                            flush=True,
                        )

        if hasattr(self, "cleanup"):
            self.cleanup()

    def _latest_frame_from_env(self) -> Any:
        raw = self.arc_env.observation_space
        if raw is None and hasattr(self.arc_env, "reset"):
            raw = self.arc_env.reset()
        if hasattr(self, "_convert_raw_frame_data"):
            return self._convert_raw_frame_data(raw)
        return raw

    def _take_arc_action(self, action: Any) -> Any:
        if hasattr(self, "take_action"):
            return self.take_action(action)
        data = action.action_data.model_dump() if hasattr(action, "action_data") else {}
        raw = self.arc_env.step(
            action,
            data=data,
            reasoning=data.get("reasoning", {}) if isinstance(data, dict) else {},
        )
        if hasattr(self, "_convert_raw_frame_data"):
            return self._convert_raw_frame_data(raw)
        return raw

    def is_done(self, frames: list[Any], latest_frame: Any) -> bool:
        try:
            _, GameState = _import_game_action_api()
            return latest_frame.state is GameState.WIN
        except Exception:
            status = _extract_status(latest_frame).upper()
            return status in {"WIN", "DONE", "FINISHED"}

    def choose_action(self, frames: list[Any], latest_frame: Any):
        grid = _extract_grid(latest_frame)
        game_id = _extract_game_id(latest_frame)
        status = _extract_status(latest_frame).upper()
        action_space = _extract_action_space(latest_frame)

        # Fresh game (or first-ever call): create the agent.
        # IMPORTANT: only do this on game_id change — NOT on GAME_OVER / NOT_PLAYED
        # status. The earlier code nulled self.agent on every GAME_OVER, wiping
        # the hypothesis bank and replay buffer; cross-level memory then never
        # had a chance to apply.
        if self.agent is None or self.game_id != game_id:
            self.game_id = game_id
            self.agent = ACCAAgent(game_id=game_id, memory=self.memory)
            self.agent.reset(
                {
                    "game_id": game_id,
                    "initial_grid": grid,
                    "action_space": action_space,
                }
            )
            self.probe_step = 0
            self.click_targets = _click_targets(grid)
            self._prev_signature = _frame_signature(grid)
            if status in {"GAME_OVER", "NOT_PLAYED"}:
                self.last_action = "RESET"
                return _to_game_action("RESET")

        # GAME_OVER / NOT_PLAYED mid-game: send RESET to retry the level, but
        # KEEP the agent and its bank intact. GAME_OVER is a level-failure
        # signal — feed it to on_level_complete so MechanicMemory + goal_inference
        # can learn from the failure.
        if status in {"GAME_OVER", "NOT_PLAYED"}:
            if status == "GAME_OVER":
                try:
                    self.agent.on_level_complete(grid, success=False)
                except Exception:
                    pass
            self.probe_step = 0
            self.click_targets = _click_targets(grid)
            self.agent.on_new_level()
            self._prev_signature = _frame_signature(grid)
            self.last_action = "RESET"
            return _to_game_action("RESET")

        # Level transition detection: shape, palette, or >=70% non-bg change.
        # A transition WITHOUT a GAME_OVER status is treated as a level win —
        # feed it to on_level_complete so the action sequence that got us here
        # is saved to MechanicMemory and replayed via program_candidates next
        # level. This is the cross-level learning loop that was previously
        # disconnected (bridge never called on_level_complete).
        sig = _frame_signature(grid)
        if self._prev_signature is not None and _is_level_transition(self._prev_signature, sig):
            try:
                self.agent.on_level_complete(grid, success=True)
            except Exception:
                pass
            self.probe_step = 0
            self.click_targets = _click_targets(grid)
            self.agent.on_new_level()
        self._prev_signature = sig

        probe = self._probe_action(grid, action_space)
        if probe is not None:
            self.probe_step += 1
            self.last_action = probe
            return _to_game_action(probe)

        action = self.agent.act(grid)
        self.last_action = str(action)
        return _to_game_action(self.last_action)

    def _probe_action(self, grid: np.ndarray, action_space: list[str]) -> str | None:
        """Short bootstrapping probe: 1 cycle of available simple actions + up to
        4 ACTION6 click probes from the per-level candidate set. ACCAAgent's
        own _coordinate_action takes over from there with a richer policy."""
        simple = [a for a in ("ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5", "ACTION7") if a in action_space]
        click_probe_budget = 4 if "ACTION6" in action_space else 0

        if click_probe_budget > 0 and self.probe_step < click_probe_budget:
            if not self.click_targets:
                self.click_targets = _click_targets(grid)
            if self.click_targets:
                row, col = self.click_targets[self.probe_step % len(self.click_targets)]
                return f"ACTION6 {row} {col}"

        offset = self.probe_step - click_probe_budget
        if offset < len(simple):
            return simple[offset]
        return None


class RandomClickAgent(_OfficialAgent):
    """Sanity baseline — random clicks (70%) + random simple actions (30%).

    Used to confirm the SDK / scorecard wiring is correct independently of the
    ACCA policy: if THIS agent scores 0 on every game, the bug is in the bridge;
    if it scores > 0 anywhere, the bug is in ACCA's policy. Toggle on with the
    env var `ACCA_USE_RANDOM_BASELINE=1` before `run_competition()`."""

    MAX_ACTIONS = 300

    def __init__(self, *args: Any, **kwargs: Any):
        if _OfficialAgent is not object:
            super().__init__(*args, **kwargs)
        else:
            for name, value in kwargs.items():
                setattr(self, name, value)
            self.frames = []
            self.action_counter = 0
        import random
        self._rng = random.Random(0)
        self.game_id: str | None = None
        self.last_action: str | None = None

    def main(self) -> None:
        if not hasattr(self, "arc_env") or self.arc_env is None:
            raise RuntimeError("RandomClickAgent requires an arc_env before main().")
        latest_frame = self._latest_frame_from_env()
        if not getattr(self, "frames", None):
            self.frames = [latest_frame]
        self.action_counter = int(getattr(self, "action_counter", 0))
        while not self.is_done(self.frames, latest_frame) and self.action_counter < self.MAX_ACTIONS:
            action = self.choose_action(self.frames, latest_frame)
            frame = self._take_arc_action(action)
            if frame is not None:
                latest_frame = frame
                if hasattr(self, "append_frame"):
                    self.append_frame(frame)
                else:
                    self.frames.append(frame)
            self.action_counter += 1
        if hasattr(self, "cleanup"):
            self.cleanup()

    def _latest_frame_from_env(self) -> Any:
        raw = self.arc_env.observation_space
        if hasattr(self, "_convert_raw_frame_data"):
            return self._convert_raw_frame_data(raw)
        return raw

    def _take_arc_action(self, action: Any) -> Any:
        if hasattr(self, "take_action"):
            return self.take_action(action)
        data = action.action_data.model_dump() if hasattr(action, "action_data") else {}
        raw = self.arc_env.step(
            action,
            data=data,
            reasoning=data.get("reasoning", {}) if isinstance(data, dict) else {},
        )
        if hasattr(self, "_convert_raw_frame_data"):
            return self._convert_raw_frame_data(raw)
        return raw

    def is_done(self, frames: list[Any], latest_frame: Any) -> bool:
        try:
            _, GameState = _import_game_action_api()
            return latest_frame.state is GameState.WIN
        except Exception:
            status = _extract_status(latest_frame).upper()
            return status in {"WIN", "DONE", "FINISHED"}

    def choose_action(self, frames: list[Any], latest_frame: Any):
        status = _extract_status(latest_frame).upper()
        if status in {"GAME_OVER", "NOT_PLAYED"}:
            return _to_game_action("RESET")
        grid = _extract_grid(latest_frame)
        action_space = _extract_action_space(latest_frame)
        if "ACTION6" in action_space and self._rng.random() < 0.7:
            h, w = grid.shape
            r = self._rng.randint(0, max(0, h - 1))
            c = self._rng.randint(0, max(0, w - 1))
            return _to_game_action(f"ACTION6 {r} {c}")
        simple = [a for a in action_space if a not in ("RESET", "ACTION6")]
        if simple:
            return _to_game_action(self._rng.choice(simple))
        return _to_game_action("RESET")


def _click_targets(grid: np.ndarray) -> list[tuple[int, int]]:
    if grid.size == 0:
        return []
    height, width = grid.shape
    targets: list[tuple[int, int]] = []
    for color in sorted(int(c) for c in np.unique(grid) if int(c) != 0):
        ys, xs = np.where(grid == color)
        if len(ys) == 0:
            continue
        targets.append((int(np.median(ys)), int(np.median(xs))))
        if len(ys) <= 16:
            targets.extend((int(y), int(x)) for y, x in zip(ys, xs))
    targets.extend(
        [
            (height // 2, width // 2),
            (height // 4, width // 4),
            (height // 4, (3 * width) // 4),
            ((3 * height) // 4, width // 4),
            ((3 * height) // 4, (3 * width) // 4),
        ]
    )
    seen: set[tuple[int, int]] = set()
    out: list[tuple[int, int]] = []
    for row, col in targets:
        row = max(0, min(height - 1, row))
        col = max(0, min(width - 1, col))
        target = (row, col)
        if target not in seen:
            seen.add(target)
            out.append(target)
    return out[:32]


def register_acca_agent() -> None:
    root = _official_agents_root()
    if root is not None:
        _ensure_lightweight_agents_package(root)
    pkg = sys.modules.get("agents")
    if pkg is None:
        pkg = types.ModuleType("agents")
        sys.modules["agents"] = pkg
    available = getattr(pkg, "AVAILABLE_AGENTS", {})
    available["acca"] = KaggleACCAAgent
    setattr(pkg, "AVAILABLE_AGENTS", available)


def run_competition() -> None:
    """Run ACCA (or the RandomClickAgent baseline) through the official Arcade.

    Set `ACCA_USE_RANDOM_BASELINE=1` to swap in `RandomClickAgent` — useful for
    A/B-testing whether the bridge wiring is correct independently of ACCA's
    policy. Tag suffix `-random` is added to the scorecard so the runs are
    distinguishable from production submissions.
    """
    import os

    try:
        _add_official_agent_paths()
        Arcade, OperationMode = _import_arcade_api()
    except Exception as exc:  # pragma: no cover - requires Kaggle SDK.
        raise RuntimeError(
            "ARC-AGI-3 SDK is unavailable. Install from Kaggle's "
            "arc_agi_3_wheels/ directory before calling run_competition(). "
            + _agent_path_diagnostics()
        ) from exc

    use_random_baseline = os.environ.get("ACCA_USE_RANDOM_BASELINE") == "1"
    AgentClass = RandomClickAgent if use_random_baseline else KaggleACCAAgent
    agent_name = "random-baseline" if use_random_baseline else "acca"

    if _competition_mode_available():
        arcade = Arcade(operation_mode=OperationMode.COMPETITION)
    else:
        env_dir = _public_environment_dir()
        if env_dir is None:
            raise RuntimeError(
                "No ARC API key is available for competition mode, and no "
                "environment_files/ directory was found for offline smoke mode."
            )
        arcade = Arcade(operation_mode=OperationMode.OFFLINE, environments_dir=env_dir)
    games = [_game_id_of(game) for game in arcade.get_environments()]
    register_acca_agent()
    mode_tag = "competition" if _competition_mode_available() else "offline-smoke"
    tags = [agent_name, mode_tag]
    card_id = arcade.open_scorecard(tags=tags)
    try:
        for game_id in games:
            env = arcade.make(game_id, scorecard_id=card_id)
            agent = AgentClass(
                card_id=card_id,
                game_id=game_id,
                agent_name=agent_name,
                ROOT_URL="http://localhost:8001",
                record=False,    # was True; recording is a common slowness culprit
                arc_env=env,
                tags=tags,
            )
            agent.main()
    finally:
        scorecard = arcade.close_scorecard(card_id)
        print(scorecard)
